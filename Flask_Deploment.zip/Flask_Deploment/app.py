import pandas as pd
import numpy as np
import sklearn
import joblib
from flask import Flask,render_template,request
app=Flask(__name__)

@app.route('/')
def home():
	return render_template('home.html')

@app.route('/predict',methods=['GET','POST'])

def predict():
	if request.method =='POST':
		print(request.form.get('latitude'))
		print(request.form.get('longitude'))
		print(request.form.get('room_type'))
		print(request.form.get('minimum_nights'))
		print(request.form.get('availability_365'))
		try:
			latitude=float(request.form['latitude'])
			longitude=float(request.form['longitude'])
			room_type=float(request.form['room_type'])
			minimum_nights=float(request.form['minimum_nights'])
			availability_365=float(request.form['availability_365'])
			pred_args=[latitude,longitude,room_type,minimum_nights,availability_365]
			pred_arr=np.array(pred_args)
			#print(pred_arr)
			preds=pred_arr.reshape(1,-1)
			model=open("linear_regression_model.pkl","rb")
			lr_model=joblib.load(model)
			model_prediction=lr_model.predict(preds)			
			model_prediction=round(float(model_prediction),2)
		except ValueError:
			return "Please Enter valid values"
	return render_template('predict.html',prediction=model_prediction)
if __name__=='__main__':
	app.run(debug=True)
